My program will takeup a huge amount of memory ifrun with full data.
My program sill also be not able to finish the task in time for full data.
My program can probably handle 1000000 lines of data.
My program reads file first so if provided with full data it might not be able to function.
I have set the program to read at most 1000000 data lines which can be changed by modifying 
const int limit
in line 11